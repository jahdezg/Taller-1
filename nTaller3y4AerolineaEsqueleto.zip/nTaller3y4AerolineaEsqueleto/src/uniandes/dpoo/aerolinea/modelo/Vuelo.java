package uniandes.dpoo.aerolinea.modelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

import java.util.Collection;
import java.util.Objects;

public class Vuelo 
{
	private String fecha;
	
	public Vuelo(String fecha)
	{
		this.fecha = fecha;
	}
	public Ruta getRuta()
	{
		return null;
	}
	public String getFecha()
	{
		return null;
	}
	public Avion getAvion()
	{
		return null;
	}
	public Collection<Tiquete> getTiquetes()
	{
		return null;
	}
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad)
	{
		return -1;
	}
	public Boolean equals(Objects obj)
	{
		return null;
	}

}
