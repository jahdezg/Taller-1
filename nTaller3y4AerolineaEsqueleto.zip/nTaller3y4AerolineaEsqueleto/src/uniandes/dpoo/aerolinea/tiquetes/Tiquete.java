package uniandes.dpoo.aerolinea.tiquetes;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class Tiquete 
{
	private String codigo;
	private int tarifa;
	private Boolean usado;
	
	public Tiquete(String codigo, int tarifa, Boolean usado)
	{
		this.codigo = codigo;
		this.tarifa = tarifa;
		this.usado = usado;
	}
	public Cliente getCliente()
	{
		return null;
	}
	public Vuelo getVuelo()
	{
		return null;
	}
	public String getCodigo()
	{
		return null;
	}
	public int getTarifa()
	{
		return -1;
	}
	public void marcarComoUsado()
	{}
	public Boolean esUsado()
	{
		return null;
	}
}
